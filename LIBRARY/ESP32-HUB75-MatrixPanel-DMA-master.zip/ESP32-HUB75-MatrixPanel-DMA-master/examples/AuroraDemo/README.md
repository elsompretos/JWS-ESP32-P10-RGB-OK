A port of Aurora visualisations
======

Not all of the visualisations have been ported. About 17 of 37 work, or have been included as I think they look best.

Original source: https://github.com/pixelmatix/aurora