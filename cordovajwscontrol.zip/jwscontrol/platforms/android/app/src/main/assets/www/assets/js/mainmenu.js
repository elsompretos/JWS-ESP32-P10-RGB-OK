$(document).ready(function(){
    $("#btn_waktu").click(function(){
        window.location.href = "waktu.html";
    });
    
    $("#btn_pengaturan").click(function(){
        window.location.href = "pengaturan.html";
    });
    
    $("#btn_lokasi").click(function(){
        window.location.href = "lokasi.html";
    });
    
    $("#btn_koreksi").click(function(){
        window.location.href = "koreksi.html";
    });
    
    $("#btn_tpl_jadwal").click(function(){
        window.location.href = "tampiljadwal.html";
    });
    
    $("#btn_informasi").click(function(){
        window.location.href = "informasi.html";
    });
    
    $("#btn_tpl_informasi").click(function(){
        window.location.href = "tampilinformasi.html";
    });
    
    $("#btn_adzan_iqomah").click(function(){
        window.location.href = "adzaniqomah.html";
    });
    
    $("#btn_tartil").click(function(){
        window.location.href = "tartil.html";
    });
    
    $("#btn_warna").click(function(){
        window.location.href = "warna.html";
    });
});