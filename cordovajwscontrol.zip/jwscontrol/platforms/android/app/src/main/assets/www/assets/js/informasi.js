$(document).ready(function(){   
  $("#btn_back_info").click(function(){
    window.location.href = "mainmenu.html";
  });
});
